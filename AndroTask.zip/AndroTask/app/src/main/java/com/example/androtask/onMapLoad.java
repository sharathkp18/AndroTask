package com.example.androtask;

public interface onMapLoad {
    void onMapLoaded();
}
